# jquery-slidein
A slide-in panel for JQueryUI that works from all four sides
